<?php
        header("Location: https://docs.keyauth.com/");
        exit();
?>