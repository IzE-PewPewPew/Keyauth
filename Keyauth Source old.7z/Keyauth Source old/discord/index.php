<?php
        header("Location: https://discord.gg/8CqcCTbEEh");
        exit();
?>